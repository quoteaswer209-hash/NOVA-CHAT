import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Search, Plus, Settings, MessageCircle, Users, Radio, Phone, Sparkles,
  Send, Paperclip, Moon, Sun, Wifi, WifiOff, LogOut, Menu, X, CheckCheck
} from "lucide-react";
import { supabase, isSupabaseConfigured } from "./lib/supabase";
import { localDb, type LocalMessage } from "./lib/db";
import { savePendingMessage, syncPendingMessages } from "./lib/messages";

type Chat = { id: string; name: string; preview: string; time: string; unread: number; color: string };
const initialChats: Chat[] = [
  { id: "local-friends", name: "الأصدقاء", preview: "أهلًا! عاملين إيه؟", time: "12:45", unread: 2, color: "violet" },
  { id: "local-work", name: "فريق العمل", preview: "تم إرسال الملف", time: "11:20", unread: 0, color: "blue" },
  { id: "local-sara", name: "سارة", preview: "تمام، أشوفك قريبًا", time: "أمس", unread: 0, color: "pink" },
  { id: "local-family", name: "العائلة", preview: "صباح الخير ❤️", time: "أمس", unread: 4, color: "orange" }
];

export default function App() {
  const [chats, setChats] = useState(initialChats);
  const [active, setActive] = useState(initialChats[0]);
  const [messages, setMessages] = useState<LocalMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [online, setOnline] = useState(navigator.onLine);
  const [dark, setDark] = useState(true);
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState("الكل");
  const [userId, setUserId] = useState<string | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [authError, setAuthError] = useState("");
  const [showAuth, setShowAuth] = useState(false);

  useEffect(() => {
    const onOnline = () => { setOnline(true); void syncPendingMessages(); };
    const onOffline = () => setOnline(false);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    void syncPendingMessages();
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, []);

  useEffect(() => {
    let mounted = true;
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => {
      if (mounted) setUserId(data.session?.user.id ?? null);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUserId(session?.user.id ?? null);
    });
    return () => { mounted = false; listener.subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    let live = true;
    localDb.messages.where("conversation_id").equals(active.id).sortBy("created_at")
      .then(rows => { if (live) setMessages(rows); });
    return () => { live = false; };
  }, [active.id]);

  const visibleChats = useMemo(() => chats.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) &&
    (tab !== "غير مقروءة" || c.unread > 0)
  ), [chats, search, tab]);

  async function authenticate(mode: "signin" | "signup") {
    if (!supabase) return;
    setAuthBusy(true); setAuthError("");
    const result = mode === "signup"
      ? await supabase.auth.signUp({ email, password })
      : await supabase.auth.signInWithPassword({ email, password });
    if (result.error) setAuthError(result.error.message);
    else setShowAuth(false);
    setAuthBusy(false);
  }

  async function sendMessage() {
    const content = draft.trim();
    if (!content) return;
    const message: LocalMessage = {
      id: crypto.randomUUID(), conversation_id: active.id,
      sender_id: userId ?? "local-user", content,
      created_at: new Date().toISOString(), status: "pending"
    };
    await savePendingMessage(message);
    setMessages(prev => [...prev, message]);
    setDraft("");
    setChats(prev => prev.map(c => c.id === active.id
      ? { ...c, preview: content, time: "الآن" } : c));
    if (navigator.onLine && supabase && userId && !active.id.startsWith("local-")) {
      await syncPendingMessages();
      const updated = await localDb.messages.get(message.id);
      if (updated) setMessages(prev => prev.map(m => m.id === message.id ? updated : m));
    }
  }

  async function signOut() {
    await supabase?.auth.signOut();
    setUserId(null);
  }

  return (
    <main className={dark ? "app dark" : "app light"} dir="rtl">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="topbar">
        <div className="brand"><div className="brand-mark">N</div><div><b>NOVA</b><span>CHAT</span></div></div>
        <div className="top-actions">
          <div className={`connection ${online ? "online" : "offline"}`}>
            {online ? <Wifi size={15}/> : <WifiOff size={15}/>}
            <span>{online ? "متصل" : "بدون إنترنت"}</span>
          </div>
          <button className="icon-btn" onClick={() => setDark(!dark)} aria-label="تغيير المظهر">{dark ? <Sun/> : <Moon/>}</button>
          <button className="icon-btn" onClick={() => setShowAuth(true)} aria-label="الحساب"><Settings/></button>
          {userId && <button className="icon-btn" onClick={signOut} aria-label="تسجيل الخروج"><LogOut/></button>}
        </div>
      </header>

      <section className="workspace">
        <aside className="sidebar panel">
          <div className="profile-row">
            <div className="avatar self">N<span className="status-dot"/></div>
            <div className="profile-copy"><b>مرحبًا بك في NOVA</b><small>{userId ? "حساب متصل" : "وضع محلي — سجّل الدخول للمزامنة"}</small></div>
            <button className="new-chat icon-btn"><Plus size={19}/></button>
          </div>
          <label className="searchbox"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="ابحث في المحادثات..." /></label>
          <div className="tabs">{["الكل", "غير مقروءة", "المفضلة"].map(t => <button key={t} className={tab === t ? "selected" : ""} onClick={() => setTab(t)}>{t}</button>)}</div>
          <div className="section-label">المحادثات <span>{visibleChats.length}</span></div>
          <div className="chat-list">
            {visibleChats.map(chat => <button key={chat.id} className={`chat-item ${active.id === chat.id ? "active" : ""}`} onClick={() => setActive(chat)}>
              <div className={`avatar ${chat.color}`}>{chat.name.slice(0,1)}{chat.id === active.id && <i/>}</div>
              <div className="chat-info"><div className="chat-title"><b>{chat.name}</b><time>{chat.time}</time></div><div className="chat-preview"><span>{chat.preview}</span>{chat.unread > 0 && <em>{chat.unread}</em>}</div></div>
            </button>)}
            {visibleChats.length === 0 && <div className="empty-small">لا توجد محادثات مطابقة</div>}
          </div>
          <div className="sidebar-bottom"><span><span className="pulse"/> NOVA CHAT v0.1</span><span>تجربة أولية</span></div>
        </aside>

        <section className="conversation panel">
          <div className="conversation-head">
            <div className="avatar violet">{active.name.slice(0,1)}<i/></div>
            <div className="head-copy"><b>{active.name}</b><small><span className="online-text">●</span> محادثة محلية تجريبية</small></div>
            <div className="head-actions"><button className="icon-btn" title="مكالمة صوتية"><Phone/></button><button className="icon-btn" title="مكالمة فيديو"><Users/></button><button className="icon-btn" title="المزيد"><Menu/></button></div>
          </div>
          <div className="messages-area">
            <div className="date-divider"><span>بداية المحادثة</span></div>
            <div className="welcome-card"><div className="welcome-icon"><Sparkles/></div><b>أهلًا بك في NOVA CHAT</b><p>مساحة تواصل بسيطة. اكتب رسالة لتجربة الحفظ المحلي والعمل دون اتصال.</p></div>
            {messages.map(m => <motion.div initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} key={m.id} className="message-row mine">
              <div className="bubble"><p>{m.content}</p><div className="message-meta"><time>{new Date(m.created_at).toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit"})}</time>{m.status === "sent" ? <CheckCheck size={14}/> : <span>{m.status === "pending" ? "قيد الإرسال" : "تعذر الإرسال"}</span>}</div></div>
            </motion.div>)}
          </div>
          <div className="composer-wrap">
            {!online && <div className="offline-note"><WifiOff size={14}/> أنت غير متصل — ستُحفظ الرسائل محليًا للمزامنة لاحقًا</div>}
            <div className="composer"><button className="attach icon-btn" title="إرفاق ملف"><Paperclip/></button><input value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => { if (e.key === "Enter") void sendMessage(); }} placeholder="اكتب رسالتك هنا..." /><button className="send-btn" onClick={() => void sendMessage()} aria-label="إرسال"><Send size={18}/></button></div>
            <div className="composer-foot"><span>رسائلك المحلية محفوظة على هذا الجهاز</span><span>اضغط Enter للإرسال</span></div>
          </div>
        </section>

        <aside className="right-rail">
          <div className="rail-card panel"><div className="rail-icon"><Sparkles/></div><b>NOVA AI</b><p>مساعد ذكي قيد التجهيز. لن تُرسل محادثاتك إلى أي خدمة خارجية في هذه النسخة.</p><button disabled>قريبًا</button></div>
          <div className="rail-card panel"><div className="rail-icon blue-icon"><Users/></div><b>المجموعات</b><p>أنشئ مساحات مشتركة وتواصل مع فريقك.</p><button disabled>قريبًا</button></div>
          <div className="rail-card panel"><div className="rail-icon pink-icon"><Radio/></div><b>القنوات والحالات</b><p>تابع التحديثات وشارك لحظاتك.</p><button disabled>قريبًا</button></div>
          <div className="secure-note"><div>✦</div><span>الخصوصية أولًا</span><small>لا يوجد تشفير طرفي في هذه النسخة. لا تستخدمها لمعلومات حساسة.</small></div>
        </aside>
      </section>

      {showAuth && <div className="modal-backdrop" onClick={() => setShowAuth(false)}><div className="auth-modal panel" onClick={e => e.stopPropagation()}>
        <button className="close-btn icon-btn" onClick={() => setShowAuth(false)}><X/></button>
        <div className="brand modal-brand"><div className="brand-mark">N</div><div><b>NOVA</b><span>CHAT</span></div></div>
        <h2>حساب NOVA</h2><p>سجّل الدخول لربط حسابك بالخادم ومزامنة الرسائل.</p>
        {!isSupabaseConfigured && <div className="config-warning">لم يتم إعداد Supabase بعد. أضف بيانات المشروع في ملف .env.</div>}
        <input className="form-input" type="email" placeholder="البريد الإلكتروني" value={email} onChange={e => setEmail(e.target.value)} />
        <input className="form-input" type="password" placeholder="كلمة المرور" value={password} onChange={e => setPassword(e.target.value)} />
        {authError && <div className="auth-error">{authError}</div>}
        <button className="primary-wide" disabled={!supabase || authBusy || !email || password.length < 6} onClick={() => void authenticate("signin")}>{authBusy ? "جارٍ التنفيذ..." : "تسجيل الدخول"}</button>
        <button className="secondary-wide" disabled={!supabase || authBusy || !email || password.length < 6} onClick={() => void authenticate("signup")}>إنشاء حساب جديد</button>
      </div></div>}
      <footer className="mobile-footer"><button><MessageCircle/>الدردشات</button><button><Users/>المجموعات</button><button><Phone/>المكالمات</button><button><Settings/>الإعدادات</button></footer>
    </main>
  );
}
