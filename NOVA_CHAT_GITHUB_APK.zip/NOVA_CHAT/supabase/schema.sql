-- NOVA CHAT starter schema. Apply in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text not null default 'NOVA User',
  avatar_url text,
  bio text,
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  type text not null default 'direct' check (type in ('direct','group')),
  title text,
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('member','admin','owner')),
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  message_type text not null default 'text',
  content text not null default '',
  created_at timestamptz not null default now(),
  edited_at timestamptz,
  deleted_at timestamptz
);

create index if not exists messages_conversation_created_idx
  on public.messages(conversation_id, created_at desc);
create index if not exists conversation_members_user_idx
  on public.conversation_members(user_id);

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

create policy "profiles readable by authenticated users"
on public.profiles for select to authenticated using (true);
create policy "users create own profile"
on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "users update own profile"
on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "members can view conversations"
on public.conversations for select to authenticated
using (exists (select 1 from public.conversation_members cm
  where cm.conversation_id = id and cm.user_id = auth.uid()));

create policy "members can view membership"
on public.conversation_members for select to authenticated
using (user_id = auth.uid() or exists (
  select 1 from public.conversation_members cm
  where cm.conversation_id = conversation_id and cm.user_id = auth.uid()
));

create policy "members can read messages"
on public.messages for select to authenticated
using (exists (select 1 from public.conversation_members cm
  where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()));

create policy "members can send messages as themselves"
on public.messages for insert to authenticated
with check (sender_id = auth.uid() and exists (
  select 1 from public.conversation_members cm
  where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()
));

create policy "sender can edit own messages"
on public.messages for update to authenticated
using (sender_id = auth.uid())
with check (sender_id = auth.uid());

-- Enable Realtime for messages from the Supabase Dashboard if desired.
